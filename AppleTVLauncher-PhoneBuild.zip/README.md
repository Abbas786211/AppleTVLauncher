# Apple TV Launcher
1. Android Studio (Koala+) -> Open this folder; let Gradle sync (it creates the wrapper).
2. Build > Build APK(s): app/build/outputs/apk/debug/app-debug.apk. CLI: `gradle assembleDebug` (or `./gradlew` after sync).
3. Install, press Home, choose "Apple TV Launcher" -> Always.
