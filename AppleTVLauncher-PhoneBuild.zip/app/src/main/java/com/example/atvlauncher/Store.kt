package com.example.atvlauncher
import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color

/** All preferences: reactive map backed by SharedPreferences (persisted instantly). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("atv", 0)
    private val m = mutableStateMapOf<String, String>().apply { p.all.forEach { (k, v) -> put(k, v.toString()) } }
    var last by mutableLongStateOf(System.currentTimeMillis())
    fun put(k: String, v: Any) { m[k] = v.toString(); p.edit().putString(k, v.toString()).apply() }
    fun f(k: String, d: Float) = m[k]?.toFloatOrNull() ?: d
    fun b(k: String, d: Boolean) = m[k]?.toBooleanStrictOrNull() ?: d
    fun s(k: String, d: String) = m[k] ?: d
    fun c(k: String, d: Long) = Color(m[k]?.toIntOrNull() ?: d.toInt())
    fun list(k: String) = m[k]?.split(",")?.filter { it.isNotEmpty() } ?: emptyList()
    fun putList(k: String, l: List<String>) = put(k, l.joinToString(","))
}

data class Pal(val top: Color, val bot: Color, val tile: Color, val text: Color, val acc: Color)

fun palette(s: Store): Pal {
    val acc = s.c("acc", 0xFF0A84FF)
    return when (s.s("theme", "tv")) {
        "dark" -> Pal(Color(0xFF1C1C1E), Color(0xFF050505), Color.White, Color.White, acc)
        "light" -> Pal(Color(0xFFF2F2F7), Color(0xFFC7C7CC), Color(0xFF8E8E93), Color(0xFF111111), acc)
        "amoled" -> Pal(Color.Black, Color.Black, Color.White, Color.White, acc)
        "custom" -> Pal(s.c("bgc", 0xFF1C1C1E), s.c("bg2", 0xFF000000), s.c("tc", 0xFFFFFFFF), s.c("txc", 0xFFFFFFFF), acc)
        else -> Pal(Color(0xFF2B3A67), Color(0xFF0B0B14), Color.White, Color.White, acc)
    }
}
val gradients = listOf(
    listOf(0xFF3A1C71, 0xFFD76D77, 0xFFFFAF7B), listOf(0xFF0F2027, 0xFF203A43, 0xFF2C5364),
    listOf(0xFF1D2671, 0xFFC33764, 0xFF0B0B14), listOf(0xFF134E5E, 0xFF71B280, 0xFF0B0B14))
