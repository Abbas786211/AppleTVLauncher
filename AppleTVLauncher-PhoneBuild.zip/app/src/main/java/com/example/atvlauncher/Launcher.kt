package com.example.atvlauncher
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

data class App(val label: String, val pkg: String, val icon: ImageBitmap)

suspend fun loadApps(ctx: Context): List<App> = withContext(Dispatchers.Default) {
    val pm = ctx.packageManager
    val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0) +
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER), 0)
    l.distinctBy { it.activityInfo.packageName }.map {
        App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(160, 160).asImageBitmap())
    }.sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, s: Store, a: App) {
    val i = ctx.packageManager.getLaunchIntentForPackage(a.pkg) ?: return
    s.putList("rec", (listOf(a.pkg) + s.list("rec").filter { it != a.pkg }).take(12))
    val o = if (s.b("anim", true)) ActivityOptions.makeCustomAnimation(ctx, android.R.anim.fade_in, android.R.anim.fade_out).toBundle() else null
    ctx.startActivity(i, o)
}

@Composable
fun LauncherApp(s: Store) {
    val ctx = LocalContext.current
    val p = palette(s)
    var apps by remember { mutableStateOf<List<App>>(emptyList()) }
    LaunchedEffect(Unit) { apps = loadApps(ctx) }
    var panel by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf("") }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    BackHandler(panel || search) { panel = false; search = false }
    val byPkg = apps.associateBy { it.pkg }
    val dur = if (s.b("anim", true)) 350 else 0

    MaterialTheme(colorScheme = darkColorScheme(primary = p.acc)) {
        Box(Modifier.fillMaxSize()) {
            Wall(s, p)
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 40.dp, vertical = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (s.b("clock", true)) Column {
                        Text(SimpleDateFormat("h:mm", Locale.getDefault()).format(now), color = p.text, fontSize = 40.sp, fontWeight = FontWeight.Light)
                        Text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(now), color = p.text.copy(.7f), fontSize = 14.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton({ search = true }) { Icon(Icons.Filled.Search, "Search", tint = p.text) }
                    IconButton({ panel = true }) { Icon(Icons.Filled.Settings, "Settings", tint = p.text) }
                }
                Spacer(Modifier.height(24.dp))
                Text(sel, color = p.text, fontSize = 40.sp, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.height(52.dp))
                LazyColumn(Modifier.weight(1f)) {
                    val fav = s.list("fav").mapNotNull { byPkg[it] }
                    item { Row("Favourites", fav, s, p, true, { sel = it }, "Long-press an app to add it here") }
                    if (s.b("showRec", true)) { val rec = s.list("rec").mapNotNull { byPkg[it] }
                        if (rec.isNotEmpty()) item { Row("Recently Used", rec, s, p, false, { sel = it }) } }
                    item { Row("All Apps", apps, s, p, false, { sel = it }) }
                }
            }
            AnimatedVisibility(search, Modifier.align(Alignment.TopCenter), enter = slideInVertically(tween(dur)) { -it } + fadeIn(tween(dur)), exit = slideOutVertically(tween(dur)) { -it } + fadeOut(tween(dur))) {
                var q by remember { mutableStateOf("") }
                Column(Modifier.fillMaxWidth().background(Color(0xF0101015)).systemBarsPadding().padding(24.dp)) {
                    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search apps") })
                    val r = if (q.isBlank()) emptyList() else apps.filter { it.label.contains(q, true) }
                    Row("", r, s, p.copy(text = Color.White), false, { sel = it })
                }
            }
            AnimatedVisibility(panel, Modifier.align(Alignment.CenterEnd), enter = slideInHorizontally(tween(dur)) { it } + fadeIn(tween(dur)), exit = slideOutHorizontally(tween(dur)) { it } + fadeOut(tween(dur))) {
                SettingsPanel(s) { panel = false }
            }
            val idle = s.b("saver", true) && now - s.last > 120_000
            AnimatedVisibility(idle, enter = fadeIn(tween(1500)), exit = fadeOut(tween(300))) {
                Box(Modifier.fillMaxSize().background(Color.Black), Alignment.Center) {
                    Text(SimpleDateFormat("h:mm", Locale.getDefault()).format(now), color = Color.White.copy(.6f), fontSize = 96.sp, fontWeight = FontWeight.Thin,
                        modifier = Modifier.offset(x = ((now / 60000 % 7) * 12 - 36).dp, y = ((now / 60000 % 5) * 12 - 24).dp))
                }
            }
        }
    }
}

@Composable
fun Row(title: String, apps: List<App>, s: Store, p: Pal, isFav: Boolean, onSel: (String) -> Unit, empty: String = "") {
    Column {
        if (title.isNotEmpty()) Text(title, color = p.text.copy(.8f), fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 12.dp))
        if (apps.isEmpty() && empty.isNotEmpty()) Text(empty, color = p.text.copy(.5f), modifier = Modifier.padding(vertical = 24.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(s.f("gap", 24f).dp), contentPadding = PaddingValues(vertical = 24.dp, horizontal = 8.dp)) {
            items(apps, key = { it.pkg }) { Tile(it, s, p, onSel) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Tile(a: App, s: Store, p: Pal, onSel: (String) -> Unit) {
    val ctx = LocalContext.current
    val src = remember { MutableInteractionSource() }
    var foc by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val pr by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (foc || pr) 1.12f else 1f, if (s.b("anim", true)) spring(.7f, 300f) else snap(), label = "zoom")
    val shape = RoundedCornerShape(s.f("rad", 28f).dp)
    val sz = s.f("size", 150f).dp
    val fav = s.list("fav")
    Column(Modifier.width(sz).onFocusChanged { foc = it.isFocused; if (it.isFocused) onSel(a.label) }
        .scale(sc).combinedClickable(src, null, onClick = { launch(ctx, s, a) }, onLongClick = { menu = true }),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(sz).shadow(if (foc) 24.dp else 4.dp, shape).clip(shape)
            .background(p.tile.copy(alpha = s.f("ta", .25f))).border(if (foc) 3.dp else 0.dp, p.acc, shape).padding(sz * .14f)) {
            Image(a.icon, a.label, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
        Text(a.label, color = p.text, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        DropdownMenu(menu, { menu = false }) {
            DropdownMenuItem({ Text(if (a.pkg in fav) "Remove from favourites" else "Add to favourites") }, { s.putList("fav", if (a.pkg in fav) fav - a.pkg else fav + a.pkg); menu = false })
            if (a.pkg in fav) {
                val i = fav.indexOf(a.pkg)
                fun move(d: Int) { val l = fav.toMutableList(); Collections.swap(l, i, i + d); s.putList("fav", l); menu = false }
                if (i > 0) DropdownMenuItem({ Text("Move left") }, { move(-1) })
                if (i < fav.lastIndex) DropdownMenuItem({ Text("Move right") }, { move(1) })
            }
        }
    }
}

@Composable
fun Wall(s: Store, p: Pal) {
    val ctx = LocalContext.current
    val w = s.s("wall", "tv")
    var bmp by remember(w) { mutableStateOf<ImageBitmap?>(null) }
    if (w.startsWith("content")) LaunchedEffect(w) {
        bmp = withContext(Dispatchers.IO) { runCatching {
            ctx.contentResolver.openInputStream(Uri.parse(w))!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 })!!.asImageBitmap() } }.getOrNull() }
    }
    val colors = if (w.startsWith("g")) gradients[w.drop(1).toInt()].map { Color(it) } else listOf(p.top, p.bot)
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(colors))) {
        bmp?.let { Image(it, null, Modifier.fillMaxSize().blur(s.f("blur", 0f).dp), contentScale = ContentScale.Crop) }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = (1f - s.f("bright", .85f)).coerceIn(0f, 1f))))
    }
}

val swatches = listOf(0xFF000000, 0xFF1C1C1E, 0xFF2B3A67, 0xFF0A84FF, 0xFF5E5CE6, 0xFFBF5AF2, 0xFFFF375F, 0xFFFF9F0A, 0xFF30D158, 0xFFFFFFFF)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsPanel(s: Store, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) { runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }; s.put("wall", u.toString()) }
    }
    @Composable fun H(t: String) = Text(t, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 20.dp, bottom = 6.dp))
    @Composable fun Chips(opts: List<Pair<String, String>>, key: String, def: String) = LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(opts) { (id, name) -> FilterChip(s.s(key, def) == id, { s.put(key, id) }, { Text(name) }) } }
    @Composable fun Sl(label: String, key: String, def: Float, r: ClosedFloatingPointRange<Float>) {
        Text("$label: ${"%.2f".format(s.f(key, def))}", color = Color.White.copy(.8f), fontSize = 13.sp)
        Slider(s.f(key, def), { s.put(key, it) }, valueRange = r) }
    @Composable fun Sw(label: String, key: String, def: Long, custom: Boolean) {
        Text(label, color = Color.White.copy(.8f), fontSize = 13.sp)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(vertical = 6.dp)) {
            items(swatches) { c -> Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c))
                .border(if (s.c(key, def) == Color(c)) 3.dp else 1.dp, Color.White, CircleShape)
                .clickable { s.put(key, Color(c).toArgb()); if (custom) s.put("theme", "custom") }) } } }
    @Composable fun Tg(label: String, key: String, def: Boolean) = Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f)); Switch(s.b(key, def), { s.put(key, it) }) }

    Column(Modifier.fillMaxHeight().width(380.dp).background(Color(0xF2101015), RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp))
        .systemBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClose) { Text("Done") } }
        H("Theme")
        Chips(listOf("tv" to "Apple TV", "dark" to "Dark", "light" to "Light", "amoled" to "AMOLED", "custom" to "Custom"), "theme", "tv")
        H("Wallpaper")
        Chips(listOf("tv" to "Theme", "g0" to "Sunset", "g1" to "Ocean", "g2" to "Nebula", "g3" to "Forest"), "wall", "tv")
        Button({ pick.launch(arrayOf("image/*")) }, Modifier.padding(top = 8.dp)) { Text("Choose from gallery") }
        Sl("Blur (Android 12+)", "blur", 0f, 0f..30f); Sl("Brightness", "bright", .85f, .2f..1f)
        H("Colours")
        Sw("Accent / selection", "acc", 0xFF0A84FF, false)
        Sw("Background", "bgc", 0xFF1C1C1E, true); Sw("Gradient end", "bg2", 0xFF000000, true)
        Sw("Tile", "tc", 0xFFFFFFFF, true); Sw("Text", "txc", 0xFFFFFFFF, true)
        Sl("Tile transparency", "ta", .25f, 0f..1f)
        H("Layout")
        Sl("Icon size", "size", 150f, 90f..240f); Sl("Corner radius", "rad", 28f, 0f..70f); Sl("Spacing", "gap", 24f, 8f..60f)
        Tg("Recently used row", "showRec", true); Tg("Clock & date", "clock", true)
        H("Animations & extras")
        Tg("Animations", "anim", true); Tg("Screensaver (2 min idle)", "saver", true)
        H("Apps")
        TextButton({ s.put("fav", ""); s.put("rec", "") }) { Text("Clear favourites & recents") }
        H("About")
        Text("Apple TV Launcher 1.0\nSet as default via Android Settings → Home app.", color = Color.White.copy(.6f), fontSize = 13.sp)
    }
}
