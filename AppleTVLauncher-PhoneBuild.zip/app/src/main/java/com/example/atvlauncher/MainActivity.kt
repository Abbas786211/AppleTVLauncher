package com.example.atvlauncher
import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge

class MainActivity : ComponentActivity() {
    private lateinit var store: Store
    override fun onCreate(b: Bundle?) {
        super.onCreate(b); enableEdgeToEdge()
        store = Store(this)
        setContent { LauncherApp(store) }
    }
    override fun dispatchKeyEvent(e: KeyEvent): Boolean { store.last = System.currentTimeMillis(); return super.dispatchKeyEvent(e) }
    override fun dispatchTouchEvent(e: MotionEvent): Boolean { store.last = System.currentTimeMillis(); return super.dispatchTouchEvent(e) }
}
